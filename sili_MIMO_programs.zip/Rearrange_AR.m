function after_V=Rearrange_AR(c,N)
average_num=median(abs(c));
m1=zeros(1,N/2);
m2=zeros(1,N/2);
final_V=zeros(1,N);
s1=1;
s2=1;
for i=1:N
        if(s1>N/2)
        m2(s2)=c(i);
         s2=s2+1;
        else
    if(abs(c(i))<=average_num)
        m1(s1)=c(i);
        s1=s1+1;
    else
        m2(s2)=c(i);
        s2=s2+1;
    end
        end
end
for i=1:N/2
    final_V(2*i-1)=m1(i);
    final_V(2*i)=m2(i);
end
after_V=final_V;