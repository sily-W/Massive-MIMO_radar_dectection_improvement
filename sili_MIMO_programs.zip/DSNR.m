clear all;
close all
% Definition of the complex coefficients of the AR(p) disturbance process
p(1) = 0.5*exp(1j*2*pi*0);
p(2) = 0.3*exp(1j*2*pi*(-0.1));
p(3) = 0.4*exp(1j*2*pi*0.01);
% Power of the disturbance process
sigm2_c = 1;

% Number of antennas
Num_ant= floor(logspace(2,4,5));    % Number of antennas
Nlenth=length(Num_ant);
% Number of Monte Carlo runs
PFA_thr = 10^(-4); % threshold
decision_thr = -2*log(PFA_thr);
Spatial_V2 = 0;
SNR = [-20,-10,-5];
  % Power of complex amplitude
    PD_nom = zeros(1,Nlenth);
    PD_W_T1=zeros(3,Nlenth);
    PD_test1=zeros(1,Nlenth);
    PD_test2=zeros(1,Nlenth);
    PD_test3=zeros(1,Nlenth);
     N = 10^4;
    l=floor(Num_ant.^(1/4));
    m=[0:N-1].';
    v1=exp(1j*2*pi*Spatial_V2*m);
    nn1=zeros(1,Nlenth);
    testnum=10^3;
for count_snr=1:3
       sigm2_b=(sigm2_c)*10^(SNR(count_snr)/10);
    for ins=1:testnum
        ins
     
        alpha = sqrt(sigm2_b)*exp(1j*2*pi*rand(1));  % complex target amplitude
        x_fa = AR_gen_t_dist(N,p,sigm2_c); % as AR ouput as well
        x_pd1 = alpha * v1 + x_fa;
        % Estimation of the signal parameter alpha
        for il=1:Nlenth
        n1 = 0;

        hat_alpha_pd1 =0;
 
    for col=1:Num_ant(il)
    n1 = abs(v1(col))*abs(v1(col))+n1;

    end
    nn1(il)=n1;
      for col=1:Num_ant(il)
        hat_alpha_pd1 = conj(v1(col))*x_pd1(col)+ hat_alpha_pd1;
      end
      
        hat_alpha_pd1 =hat_alpha_pd1/n1;

        
        % Wald Test
        
        WT_decision_pd1 = Wald_test(Num_ant(il),v1,x_pd1,hat_alpha_pd1,l(il),n1);
        
        % accumalation of error      
        PD_W_T1(count_snr,il)=PD_W_T1(count_snr,il)+(sign(WT_decision_pd1-decision_thr)+1)/2;
    
        end

    
    end
end

for il=1:Nlenth

    PD_test1(il)=PD_W_T1(1,il)/testnum;
    PD_test2(il)=PD_W_T1(2,il)/testnum;
    PD_test3(il)=PD_W_T1(3,il)/testnum;
end

fid2=fopen('DSNR-AR3.txt','w+');%�洢
for count2=1:Nlenth 
    fprintf(fid2,'%f\t',PD_test1(count2));
end
fprintf(fid2,'\r\n');

for count2=1:Nlenth 
    fprintf(fid2,'%f\t',PD_test2(count2));
end

fprintf(fid2,'\r\n');

for count2=1:Nlenth 
    fprintf(fid2,'%f\t',PD_test3(count2));
end

fprintf(fid2,'\r\n');

fclose(fid2);

figure(1);
semilogx(Num_ant,PD_test1,'--b','LineWidth',2)
hold on
semilogx(Num_ant,PD_test2,'-.ro','LineWidth',2)
hold on
semilogx(Num_ant,PD_test3,'g','LineWidth',2)
hold on
grid on;
legend('SNR=-20','SNR=-10','SNR=-5');
xlabel('N');
ylabel('Rate of PD-AR(3)')