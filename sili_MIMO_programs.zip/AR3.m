clear all;
close all
clc


% Definition of the complex coefficients of the AR(p) disturbance process
p(1) = 0.5*exp(1j*2*pi*0);
p(2) = 0.3*exp(1j*2*pi*(-0.1));
p(3) = 0.4*exp(1j*2*pi*0.01);

co_matrix= - poly(p);
plot_PSD(co_matrix);

% Power of the disturbance process
sigm2_c = 1;

% Number of antennas
Num_ant= floor(logspace(2,4,5));    % Number of antennas
Nlenth=length(Num_ant);
% Number of Monte Carlo runs
testnum=zeros(1,Nlenth);
for ff=1:floor(Nlenth/2)+1;
    testnum(ff)=10^3;
end
for ff=floor(Nlenth/2)+2:Nlenth
    testnum(ff)=10^3;
end
PFA_thr = 10^(-4); % threshold
decision_thr = -2*log(PFA_thr);


% Spatial parameter
Spatial_V1 = -0.2;
Spatial_V2 = 0;
Spatial_V3 = 0.2;
SNR = -20;
sigm2_b=(sigm2_c)*10^(SNR/10);   % Power of complex amplitude
alpha = sqrt(sigm2_b)*exp(1j*2*pi*rand(1));  % complex target amplitude
PD_nom = zeros(1,Nlenth);
PD_test1 = zeros(1,Nlenth);
PD_test2 = zeros(1,Nlenth);
PD_test3 = zeros(1,Nlenth);
PFA_WDtest1 = zeros(1,Nlenth);
PFA_WDtest2 = zeros(1,Nlenth);
PFA_WDtest3 = zeros(1,Nlenth);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for il=1:Nlenth
    tic;
    PD_W_T1=0;
    PD_W_T2=0;
    PD_W_T3=0;
    PFA_W_T1=0;
    PFA_W_T2=0;
    PFA_W_T3=0;
    
    N = Num_ant(il)
    l=floor(N^(1/4));
    m=[0:N-1].';
    v1=exp(1j*2*pi*Spatial_V1*m);   % Steering vector
    v2=exp(1j*2*pi*Spatial_V2*m);
    v3=exp(1j*2*pi*Spatial_V3*m);
    n1 = (v1'*v1);
    n2 = (v2'*v2);
    n3 = (v3'*v3);
    
    for ins=1:testnum(il)
        
        x_fa = AR_gen_t_dist(N,p,sigm2_c); % as AR ouput as well
        x_pd1 = alpha * v1 + x_fa;
        x_pd2 = alpha * v2 + x_fa;
        x_pd3 = alpha * v3 + x_fa;
        % Estimation of the signal parameter alpha
        hat_alpha_pfa1 = v1'*x_fa/n1;
        hat_alpha_pd1 = v1'*x_pd1/n1;
        hat_alpha_pfa2 = v2'*x_fa/n2;
        hat_alpha_pd2 = v2'*x_pd2/n2;
        hat_alpha_pfa3 = v3'*x_fa/n3;
        hat_alpha_pd3 = v3'*x_pd3/n3;        
        
        % Wald Test
        WT_decision_pfa1 = Wald_test(N,v1,x_fa,hat_alpha_pfa1,l,n1);
        WT_decision_pfa2 = Wald_test(N,v2,x_fa,hat_alpha_pfa2,l,n2);
        WT_decision_pfa3 = Wald_test(N,v3,x_fa,hat_alpha_pfa3,l,n3);
        
        WT_decision_pd1 = Wald_test(N,v1,x_pd1,hat_alpha_pd1,l,n1);
        WT_decision_pd2 = Wald_test(N,v2,x_pd1,hat_alpha_pd2,l,n2);
        WT_decision_pd3 = Wald_test(N,v3,x_pd1,hat_alpha_pd3,l,n3);
        
        B_est_mod_1(ins) = B_matrix_est(N,v1,x_fa,0,l);
        B_est_mod_2(ins) = B_matrix_est(N,v2,x_fa,0,l);
        B_est_mod_3(ins) = B_matrix_est(N,v3,x_fa,0,l);
        % accumalation of error
        PFA_W_T1=PFA_W_T1+(sign(WT_decision_pfa1-decision_thr)+1)/2;
        PFA_W_T2=PFA_W_T2+(sign(WT_decision_pfa2-decision_thr)+1)/2;
        PFA_W_T3=PFA_W_T3+(sign(WT_decision_pfa3-decision_thr)+1)/2;
        
        PD_W_T1=PD_W_T1+(sign(WT_decision_pd1-decision_thr)+1)/2;
        PD_W_T2=PD_W_T2+(sign(WT_decision_pd2-decision_thr)+1)/2;
        PD_W_T3=PD_W_T3+(sign(WT_decision_pd3-decision_thr)+1)/2;
        
    end
    toc/60

    PFA_WDtest1(il)=PFA_W_T1/testnum(il);
    PFA_WDtest2(il)=PFA_W_T2/testnum(il);
    PFA_WDtest3(il)=PFA_W_T3/testnum(il);
    
    B_H0_mean1 = mean(B_est_mod_1);
    B_H0_mean2 = mean(B_est_mod_2);
    B_H0_mean3 = mean(B_est_mod_3);
    
    
    PD_test1(il)=PD_W_T1/testnum(il);
    PD_test2(il)=PD_W_T2/testnum(il);
    PD_test3(il)=PD_W_T3/testnum(il);
    
    non_cen_par1 = 2*abs(alpha)^2*n1^2/B_H0_mean1;
    %non_cen_par2 = 2*abs(alpha)^2*n2^2/B_H0_mean2;
    %non_cen_par3 = 2*abs(alpha)^2*n3^2/B_H0_mean3;
    PD_nom(il) = marcumq(sqrt(non_cen_par1),sqrt(decision_thr));

    
end

for count=1:Nlenth
 flag=PFA_WDtest1(count)*PFA_WDtest2(count)*PFA_WDtest3(count);
end
 %if(flag==0)
    
figure(1);
semilogx(Num_ant,PFA_WDtest1,'--b','LineWidth',2)
hold on
semilogx(Num_ant,PFA_WDtest2,'-.ro','LineWidth',2)
hold on
semilogx(Num_ant,PFA_WDtest3,'g','LineWidth',2)
hold on
semilogx(Num_ant,PFA_thr*ones(1,Nlenth),'LineWidth',2)
%axis([Nvect(1) Nvect(end) 10^(-5) 10^(-2)])
grid on;
legend('v=-0.2','v=0','v=0.2','Nominal');
xlabel('N');
ylabel('Rate of PFA-AR(3)');
figure(1);
loglog(Num_ant,PFA_WDtest1,'--b','LineWidth',2)
hold on
loglog(Num_ant,PFA_WDtest2,'-.ro','LineWidth',2)
hold on
loglog(Num_ant,PFA_WDtest3,'g','LineWidth',2)
hold on
loglog(Num_ant,PFA_thr*ones(1,Nlenth),'LineWidth',2)
%axis([Nvect(1) Nvect(end) 10^(-5) 10^(-2)])
grid on;
legend('v=-0.2','v=0','v=0.2','Nominal');
xlabel('N');
ylabel('Rate of PFA-AR(3)');


%else
   
figure(2);
loglog(Num_ant,PFA_WDtest1,'--b','LineWidth',2)
hold on
loglog(Num_ant,PFA_WDtest2,'-.ro','LineWidth',2)
hold on
loglog(Num_ant,PFA_WDtest3,'g','LineWidth',2)
hold on
loglog(Num_ant,PFA_thr*ones(1,Nlenth),'LineWidth',2)
%axis([Nvect(1) Nvect(end) 10^(-5) 10^(-2)])
grid on;
legend('v=-0.2','v=0','v=0.2','Nominal');
xlabel('N');
ylabel('Rate of PFA-AR(3)');

%end


%end
fid=fopen('PFA-AR3.txt','w+');

for count2=1:Nlenth 
    fprintf(fid,'%f\t',PFA_WDtest1(count2));
end
fprintf(fid,'\r\n');

for count2=1:Nlenth 
    fprintf(fid,'%f\t',PFA_WDtest2(count2));
end

fprintf(fid,'\r\n');

for count2=1:Nlenth 
    fprintf(fid,'%f\t',PFA_WDtest3(count2));
end
fclose(fid);



figure(3);
semilogx(Num_ant,PD_test1,'--b','LineWidth',2)
hold on
semilogx(Num_ant,PD_test2,'-.ro','LineWidth',2)
hold on
semilogx(Num_ant,PD_test3,'g','LineWidth',2)
hold on
semilogx(Num_ant,PD_nom,'LineWidth',2)
%axis([10 1000 10^(-2) 10^(-1)])
grid on;
legend('v=-0.2','v=0','v=0.2','Nominal');
xlabel('N');
ylabel('Rate of PD-AR(3)')

