% Num_ant= floor(logspace(2,4,20));
% Num_ant= [Num_ant,21544,46415,100000];
% test=zeros(1,23);
% for count=1:17
%     test(count)=PFA_W_T_est(count);
% end
% for count=18:23
%     test(count)=10^-4;
% end
% figure(2);
% loglog(Num_ant,test,'--b','LineWidth',2)
% axis([Nvect(1) Nvect(end) 10^(-5) 10^(-2)])
% grid on;
% legend('v=0');
% xlabel('N');
% ylabel('Rate of PFA-AR(3)');

a=[10+1j,9,8,7,6,5,4,3,2,1];
a=Rearrange_AR(a,10);
