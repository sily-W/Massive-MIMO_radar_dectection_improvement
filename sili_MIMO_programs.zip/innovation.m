clear all;
close all
clc
% Definition of the complex coefficients of the AR(p) disturbance process
p(1) = 0.5*exp(1j*2*pi*0);
p(2) = 0.3*exp(1j*2*pi*(-0.1));
p(3) = 0.4*exp(1j*2*pi*0.01);
co_matrix= - poly(p);
% Power of the disturbance process
sigm2_c = 1;
% Number of antennas
Num_ant= [100,50000];    % Number of antennas
Nlenth=length(Num_ant);
% Number of Monte Carlo runs
testnum=zeros(1,Nlenth);
for ff=1:floor(Nlenth/2)+1;
    testnum(ff)=10^3;
end
for ff=floor(Nlenth/2)+2:Nlenth
    testnum(ff)=10^3;
end
PFA_thr = 10^(-4); % threshold
% Spatial parameter
Spatial_V1 = 0.2;
SNR =0;
sigm2_b=(sigm2_c)*10^(SNR/10);   % Power of complex amplitude
alpha = sqrt(sigm2_b)*exp(1j*2*pi*rand(1));  % complex target amplitude
phi=zeros(1,30);

angle_current=50*pi/180;
angle_next=5*pi/180+angle_current;
N =100000;
    l=floor(N^(1/4));
  
    
for test=1:30
    hat_alpha_current=0;
    hat_alpha_next=0;
    s_next=sin(angle_next);
    s_current=sin(angle_current);
    m=[0:N-1].';
    v1=exp(1j*2*pi*Spatial_V1*m);   % Steering vector
    v_next=exp(1j*2*pi*Spatial_V1*m*s_next*2^(1/2));
    v_current=exp(1j*2*pi*Spatial_V1*m*s_current*2^(1/2));
    n1 = (v1'*v1);
         
        x_fa = AR_gen_paper(N,p,sigm2_c);
        x_pd1 = alpha * v1 + x_fa;
        % Estimation of the signal parameter alpha
        hat_alpha_current = v_current'*x_pd1/n1;
        hat_alpha_next = v_next'*x_pd1/n1;
  
        WT_decision_current = Wald_test(N,v_current,x_pd1,hat_alpha_current,l,n1);
        WT_decision_next = Wald_test(N,v_next,x_pd1,hat_alpha_next,l,n1);
        
        if WT_decision_current<WT_decision_next 
        
            phi(test)=1;
         angle_current=angle_next;
         angle_next=angle_next+5*pi/180;
        else 
          phi(test)=0;
         angle_next=angle_current;
         angle_current=angle_current-5*pi/180;
         
        end     
        
end
fid=fopen('PHI.txt','w+');

for count=1:30 
    fprintf(fid,'%f\t',phi(count));
end
fprintf(fid,'\r\n');
fclose(fid);