clear all;
close all
clc
PFA_thr=10^-4;
data_AR3=importdata('PFA-AR3V2.txt');
%data_DSNR=importdata('DNSR.txt');
Num_ant= floor(logspace(2,4,15));
%Num_ant(16)=2*10^4;
%Num_ant(17)=6*10^4;
%Num_ant(18)=10^5;
out_AR3_1=PFA_thr*ones(1,15);
out_AR3_2=PFA_thr*ones(1,15);
out_AR3_3=PFA_thr*ones(1,15);
%out_AR6_1=PFA_thr*ones(1,15);
%out_AR6_2=PFA_thr*ones(1,15);
%out_AR6_3=PFA_thr*ones(1,15);
for i=1:15
       out_AR3_1(i)=data_AR3(1,i);
out_AR3_2(i)=data_AR3(2,i);
out_AR3_3(i)=data_AR3(3,i);
% out_AR6_1(i)=data_AR6(1,i);
% out_AR6_2(i)=data_AR6(2,i);
% out_AR6_3(i)=data_AR6(3,i);
end
figure(1);
loglog(Num_ant,out_AR3_1,'--b','LineWidth',2)
hold on
loglog(Num_ant,out_AR3_2,'-.ro','LineWidth',2)
hold on
loglog(Num_ant,out_AR3_3,'g','LineWidth',2)
hold on
semilogx(Num_ant,PFA_thr*ones(1,15),'LineWidth',2)
%axis([Nvect(1) Nvect(end) 10^(-5) 10^(-2)])
grid on;
legend('v=-0.2','v=0','v=0.2','Nominal');
xlabel('N');
ylabel('Rate of PFA-AR(3)');

