 function c_norm=AR_gen_paper(N,p,sigma2_c)
Xtra=100;
p(1) = 0.5*exp(1j*2*pi*0);
p(2) = 0.3*exp(1j*2*pi*(-0.1));
p(3) = 0.4*exp(1j*2*pi*0.01);
 SUM = N+Xtra;
y=rand(1,SUM);
x=((1./(1-y)).^(1/2)-1).^(1/2);
y2=rand(1,SUM)*2*pi;
innov=x.*exp(1j*y2);

rho=poly(p);

cl = filter(1,rho,innov);
c = cl(1+Xtra:end).';
sigma2_c_est = mean(abs(c).^2);
c_norm = (c./sqrt(sigma2_c_est))*sqrt(sigma2_c);
end



