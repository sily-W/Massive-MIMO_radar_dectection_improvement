phi=importdata('PHI.txt');
len=length(phi);
theta=zeros(1,len+1);
theta_angle=zeros(1,len+1);
theta(1)=50;                             %!!!!!!!!initial!!!!!!!!
for n=2:len
    theta(n)=(phi(n)*10-5);
end
for n=2:len
    theta(n)=theta(n-1)+theta(n);
end
for n=1:len
    theta_angle(n)=theta(n)/180*pi;
end

for n=1:len
x=0:0.1:2;
y=tan(theta_angle(n))*x;
plot(x,y);
axis([0,0.2,0,0.2])
pause(1);
end 
