function B_out = B_matrix_est(N,v,x,alpha,ll)

c = x - alpha*v;
part1=0;
for col=1:N
part1 = (abs(v(col))^2 * abs(c(col))^2) +part1;
end
part2 = 0;
for m = 1:ll
    for n = m+1 : N
        part2 = part2 + 2*real(c(n)*conj(v(n))* conj(c(n-m))*v(n-m)); 
    end
end
B_out = part1 + part2;
end
