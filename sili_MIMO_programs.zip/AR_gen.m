function c_norm=AR_gen(N,p,sigma2_c)
p_abs = abs(p);
% Xtra=100*ceil(3*log(10)/abs( log( max(p_abs) ) ) ); 
Xtra=1000;
SUM = N+Xtra;


w = sqrt(1/2)*(randn(1,SUM)+1j.*randn(1,SUM));
R = gamrnd(2,1,1,SUM);
innov = sqrt(1./R).*w;%�˲�����������

rho=poly(p);

cl = filter(1,rho,innov);
c = cl(1:end-Xtra).';
sigma2_c_est = mean(abs(c).^2);
c_norm = (c./sqrt(sigma2_c_est))*sqrt(sigma2_c);
end



