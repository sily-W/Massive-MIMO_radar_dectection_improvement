function noise=disturb(N,p,sigma2_c)
% 
% v=unifrnd (-10000,10000,1,1000); 
% ll=v(1);
% syms x;
% y =(atan(x)+x/(1+x^2)) ==ll;
% x =  vpasolve(y,x)
ka=chi2rnd(2,1,N);
for count=1:N
    if ka(count)==0
        ka(count)=10^-8;
    end
end
w = sqrt(1/2)*(randn(1,N)+1j.*randn(1,N));
innov =w.*(ka/2).^(-0.5);
rho =poly(p);
c=filter(1,rho,innov);
sigma2_c_est = mean(abs(c).^2);
noise= (c./sqrt(sigma2_c_est))*sqrt(sigma2_c);
end
