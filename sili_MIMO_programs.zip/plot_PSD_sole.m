f = -0.5:0.001:0.5;
den=0;
p(1) = 0.5*exp(1j*2*pi*0);
p(2) = 0.3*exp(1j*2*pi*(-0.1));
p(3) = 0.4*exp(1j*2*pi*0.01);
for i = 1:length(p)
    den = den + p(i)*exp(-1j*2*pi*(i)*f);
end
S = 1./abs(1-den).^2;
 S_norm = S/max(S);
figure
plot(f,10*log10(S_norm))
grid on
title('Normalized PSD')


